package com.example.sfcalappointment

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
